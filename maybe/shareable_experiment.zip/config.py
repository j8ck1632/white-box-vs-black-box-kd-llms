"""
Configuration parameters for the knowledge distillation experiment.
"""

import os

# Model names
TEACHER_MODEL_NAME = "mistralai/Mistral-7B-v0.1"
STUDENT_MODEL_NAME = "TinyLlama/TinyLlama-1.1B-Chat-v1.0"

# Dataset names
SST2_DATASET = "glue"
SST2_CONFIG = "sst2"
MMLU_DATASET = "cais/mmlu"
GSM8K_DATASET = "gsm8k"

# Loss function weights
ALPHA = 1.0  # Weight for task loss (L_task)
BETA = 0.5   # Weight for KD loss (L_KD)
GAMMA_1 = 0.1  # Weight for hidden state alignment loss (L_align_hidden)
GAMMA_2 = 0.1  # Weight for attention alignment loss (L_align_attn)

# Training hyperparameters
LEARNING_RATE = 1e-4
BATCH_SIZE = 2
NUM_EPOCHS = 3
MAX_SEQ_LENGTH = 256

# Teacher model dimensions
TEACHER_HIDDEN_DIM = 4096
TEACHER_NUM_HEADS = 32

# Student model dimensions (from TinyLlama config)
STUDENT_HIDDEN_DIM = 2048
STUDENT_NUM_HEADS = 32

# Paths
# Prefer writing large artifacts to D: if available to avoid C: exhaustion.
_D_DRIVE_AVAILABLE = os.path.exists("D:\\")
OFFLINE_DATA_PATH = "D:\\offline_teacher_data" if _D_DRIVE_AVAILABLE else "./offline_teacher_data"
OUTPUT_PATH = "./results"

# Ray/temp directories (fallback to defaults if drive missing)
RAY_TMPDIR = "D:\\ray_tmp" if _D_DRIVE_AVAILABLE else None
RAY_TEMP_DIR = "D:\\ray_temp_training" if _D_DRIVE_AVAILABLE else None
SYSTEM_TEMP_DIR = "D:\\temp" if _D_DRIVE_AVAILABLE else None
RAY_SPILL_DIR = RAY_TMPDIR or "C:/ray_spill"

# Offline data compression knobs
TOP_K_LOGITS = 128          # Number of logits to keep per token
HIDDEN_STRIDE = 2           # Down-sample hidden states along sequence
ATTENTION_STRIDE = 2        # Down-sample attention maps along sequence dims
PARQUET_COMPRESSION = "zstd"
PARQUET_COMPRESSION_LEVEL = 3

# Teacher vocab size (used to reconstruct logits from top-k representation)
TEACHER_VOCAB_SIZE = 32000

# DeepSpeed configuration
ENABLE_DEEPSPEED_ZERO3 = True
DEEPSPEED_ZERO3_CONFIG = {
    "zero_optimization": {
        "stage": 3,
        "overlap_comm": True,
        "contiguous_gradients": True,
        "reduce_bucket_size": 5e7,
        "stage3_prefetch_bucket_size": 5e7,
        "stage3_param_persistence_threshold": 1e6,
        "offload_param": {
            "device": "cpu",
            "pin_memory": True,
        },
        "offload_optimizer": {
            "device": "cpu",
            "pin_memory": True,
        },
    },
    "aio": {
        "block_size": 1048576,
        "queue_depth": 16,
        "thread_count": 1,
        "single_submit": False,
        "overlap_events": True,
        "thread_pin": True,
    },
    "bf16": {
        "enabled": False
    },
}

# Ray configuration
RAY_NUM_GPUS_PER_TRIAL = 1
RAY_NUM_CPUS_PER_TRIAL = 4
# Maximum concurrent trials (None = auto-detect based on available GPUs)
# Set to a specific number to limit concurrency (e.g., 2 for a 2-GPU cluster)
RAY_MAX_CONCURRENT_TRIALS = None

# Hugging Face token (required for gated models)
# WARNING: This token is hardcoded for convenience. Do not commit this file to public repositories.
HUGGING_FACE_TOKEN = "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"

