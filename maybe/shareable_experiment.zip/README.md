# White-Box vs Black-Box Knowledge Distillation in LLMs

This repository contains the complete implementation for the research experiment comparing white-box and black-box knowledge distillation methods in causal language models.

## Overview

This experiment systematically compares different knowledge distillation signals:
- **Black-Box**: Using only final logits
- **White-Box (Hidden)**: Using logits + hidden states
- **White-Box (Attention)**: Using logits + attention maps
- **White-Box (Combined)**: Using all signals

The experiment runs 28 trials (4 groups × 7 seeds) on a Ray cluster with 28 GPUs.

### Ray-Free Multi-Machine Flow

If you would rather split work across a few standalone GPUs without Ray, use:

- `generate_teacher_manifest.py` to export a single JSON containing the teacher snapshot metadata.
- `multi_machine_runner.py` to run any distillation type sequentially on one box (e.g., Machine A handles `black_box`, Machine B runs `hidden_state`).
- `tests_dashboard.py` for a simple Tkinter GUI explaining each test and the exact CLI to launch it.
- `MULTI_MACHINE_PLAN.md` for the recommended three-machine schedule.

Need to hand teammates a single folder? Copy `shareable_bundle/` along with
`offline_teacher_data/` and ask them to drive everything via:

```
python shareable_bundle/experiment_hub.py <manifest|run|dashboard|plan> [...]
```

See `shareable_bundle/README_SHARABLE.md` for the full workflow.

### One-Command Shareable Zip

Run the packaging helper to build a ready-to-ship archive that already contains
the bundle, config templates, and docs:

```bash
python create_shareable_package.py --output shareable_experiment.zip
```

Distribute the resulting zip plus the `offline_teacher_data/` directory (kept
separate to avoid multi-GB archives).

## Project Structure

```
.
├── requirements.txt              # Python dependencies
├── config.py                     # Configuration parameters
├── distillation_student.py       # DistillationStudent model class
├── offline_teacher_data.py       # Pre-compute teacher outputs
├── train_student.py              # Main Ray Tune training script
└── README.md                     # This file
```

## Setup

### 1. Environment Setup

Create a virtual environment and install dependencies:

```bash
python -m venv venv
source venv/bin/activate  # On Windows: venv\Scripts\activate
pip install -r requirements.txt
```

### 2. Ray Cluster Setup

Initialize your Ray cluster. On a multi-node cluster:

```bash
# On head node
ray start --head

# On worker nodes
ray start --address=<head-node-ip>:10001
```

Or if using a Ray cluster manager (e.g., Ray on Kubernetes), configure according to your setup.

### 3. Configuration Setup

Copy the example configuration file and add your Hugging Face token:

```bash
cp config.py.example config.py
```

Then edit `config.py` and replace `YOUR_TOKEN_HERE` with your actual Hugging Face token:

```python
HUGGING_FACE_TOKEN = "your_actual_token_here"
```

Get your token from: https://huggingface.co/settings/tokens

**Note**: `config.py` is ignored by git (it's in `.gitignore`) to protect your token. Only `config.py.example` is tracked in the repository.

### 4. Model Access

The required HuggingFace models:
- `mistralai/Mistral-7B-v0.1` (teacher) - **Requires authentication** (gated model)
- `TinyLlama/TinyLlama-1.1B-Chat-v1.0` (student) - Public, no authentication required

Make sure you have access to the teacher model and your token is set in `config.py`.

## Usage

### Step 1: Pre-compute Teacher Data (Offline)

Run the offline teacher data generation script. This streams the datasets through the teacher model on your local machine (no Ray required) and saves compressed outputs:

```bash
python offline_teacher_data.py
```

This will:
- Load datasets (SST-2, MMLU, GSM8K)
- Run the teacher model on all prompts sequentially (streaming batches to keep RAM low)
- Save an enriched Parquet dataset to `D:\offline_teacher_data\offline_teacher_data.parquet` (or `./offline_teacher_data/` if `D:` is unavailable)

**Expected output**: A Parquet file containing:
- `prompt`: Original prompts
- `answer`: Original answers
- `teacher_topk_indices` / `teacher_topk_values`: Top‑k teacher logits per token (saves ~90% disk space vs. dense logits)
- `teacher_hidden_state`: Downsampled teacher hidden states
- `teacher_attention_map`: Downsampled teacher attention maps
- `student_input_ids`, `student_attention_mask`: Student tokenization metadata for alignment

You can adjust compression knobs (`TOP_K_LOGITS`, `HIDDEN_STRIDE`, `ATTENTION_STRIDE`, Parquet compression) in `config.py`.

#### Step 1b: Validate the Offline Dataset

Run the built-in verification utility to ensure saved tensors round-trip cleanly:

```bash
python -c "import config; import offline_teacher_data as otd; otd.verify_saved_data(config.OFFLINE_DATA_PATH, num_samples=20)"
```

Successful runs end with:

```
✓ Verified <n> random examples - all valid
✓ Data verification passed!
```

If validation fails:

- Pull latest changes (the `_to_py` helper now recursively normalizes nested numpy object arrays before Parquet writes).
- Inspect the offending row via a notebook/REPL and confirm `teacher_attention_map` remains `[num_heads, seq_len, seq_len]`.
- Regenerate offline data only if the stored tensors are truly malformed.

Optional but recommended regression check:

```bash
python -m pytest -s tests/test_offline_teacher_data.py
```

The small test suite ensures the serialization helpers keep handling nested numpy object arrays correctly. The `-s` flag bypasses a Windows console capture quirk.

### Step 2: Train Student Models

Run the main training script to launch all 28 trials:

```bash
python train_student.py
```

This will:
- Load the pre-computed teacher data
- Launch 28 Ray Tune trials (4 distillation types × 7 seeds)
- Train student models with different distillation signals
- Save results to `./results/`

**Expected runtime**: Several hours to days depending on dataset size and cluster configuration.

**Pre-flight checklist**:

- Offline Parquet validated (see Step 1b) and `config.OFFLINE_DATA_PATH` points to that snapshot.
- Ray cluster sized for planned concurrency (`RAY_MAX_CONCURRENT_TRIALS` optional throttle).
- Hugging Face token still valid (re-auth if runs start failing with 401s).
- Monitor `results/**/error.txt` plus Ray Tune dashboard for early warnings.

## Configuration

Edit `config.py` to adjust experiment parameters:

- **Loss weights**: `ALPHA`, `BETA`, `GAMMA_1`, `GAMMA_2`
- **Training hyperparameters**: `LEARNING_RATE`, `BATCH_SIZE`, `NUM_EPOCHS`
- **Model names**: `TEACHER_MODEL_NAME`, `STUDENT_MODEL_NAME`
- **Paths**: `OFFLINE_DATA_PATH`, `OUTPUT_PATH`
- **Ray resources**: `RAY_NUM_GPUS_PER_TRIAL`, `RAY_NUM_CPUS_PER_TRIAL`

## Experiment Design

### Experimental Groups

| Group | Distillation Type | Signals Used |
|-------|------------------|--------------|
| 1 | Black-Box | L_task + L_KD (logits only) |
| 2 | White-Box (Hidden) | L_task + L_KD + L_align_hidden |
| 3 | White-Box (Attention) | L_task + L_KD + L_align_attn |
| 4 | White-Box (Combined) | All signals |

### Loss Function

The total loss is computed as:

```
L_total = α·L_task + β·L_KD + γ₁·L_align_hidden + γ₂·L_align_attn
```

Where:
- `L_task`: Cross-entropy on ground truth
- `L_KD`: KL divergence on logits (black-box)
- `L_align_hidden`: MSE on hidden states (white-box)
- `L_align_attn`: MSE on attention maps (white-box)

### Evaluation Datasets

- **SST-2**: Sentiment analysis (NLU task)
- **MMLU**: Multi-task language understanding (Reasoning task)
- **GSM8K**: Grade-school math word problems (Math task)

## Results

After training completes, results will be saved to:
- `./results/results_summary.csv`: Summary of all trials
- `./results/`: Ray Tune checkpoints and detailed metrics

To analyze results:

```python
import pandas as pd

df = pd.read_csv("./results/results_summary.csv")
summary = df.groupby("config/distill_type")["validation_accuracy"].mean()
print(summary)
```

## Key Components

### DistillationStudent

The `DistillationStudent` class (`distillation_student.py`) wraps TinyLlama and adds:
- A trainable hidden state projector (2048 → 4096 dimensions)
- Methods to extract logits, hidden states, and attention maps

### Offline Teacher Data Script

The `offline_teacher_data.py` script now:
- Streams datasets sequentially on a single GPU (no Ray dependency)
- Compresses teacher outputs (top‑k logits, downsampled hidden/attention tensors)
- Writes directly to Parquet on the high-capacity drive so the run can complete on a workstation

### Training Script

The `train_student.py` script:
- Implements the `train_student` function for Ray Tune
- Configures search space for 28 trials
- Implements loss calculation based on `distill_type`
- Reports metrics back to Ray Tune

## Troubleshooting

### Out of Memory

If you encounter GPU memory issues:
- Reduce `BATCH_SIZE` in `config.py`
- Reduce `MAX_SEQ_LENGTH` in `config.py`
- Use gradient accumulation

### Ray Cluster Issues

- Ensure Ray is properly initialized: `ray status`
- Check GPU availability: `ray list nodes`
- Verify worker nodes can access shared storage

### Dataset Loading Issues

- Ensure you have internet access for HuggingFace datasets
- Some datasets may require authentication or approval
- Check dataset names in `config.py` match current HuggingFace names

### Storage & Archival

- Default offline outputs are written to `D:\offline_teacher_data` when that drive exists; otherwise they fall back to `./offline_teacher_data/`.
- After a successful verification, copy the Parquet file to an archive location with a timestamp (e.g., `offline_teacher_data_2025-11-14.parquet`) to avoid mixing older runs.
- Keep at least one validated snapshot handy so you can retrain without recomputing teacher passes if disk cleanup removes intermediate files.

## Citation

If you use this code in your research, please cite:

```
@misc{whitebox_blackbox_kd_llms,
  title={White-Box vs Black-Box Knowledge Distillation in Causal Language Models},
  author={Your Name},
  year={2024}
}
```

## License

[Specify your license here]

